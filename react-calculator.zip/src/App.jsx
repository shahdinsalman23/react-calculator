import React from 'react'
import Calculator from './components/Calculator/Calculator'
import HealthyFood from './components/HealthyFood/HealthyFood'
import TodoApp from './components/TodoApp/TodoApp'

const App = () => {
  return (
    <>
      <Calculator/>
      {/* <HealthyFood/> */}
      <TodoApp/>
    </>
  )
}

export default App